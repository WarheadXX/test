--黒竜降臨
function c100000489.initial_effect(c)
	aux.AddRitualProcGreaterCode(c,71408082)
end
